# RaceRoom Academy Website (Free Hosting)

This folder is ready to host on **GitHub Pages** (free).

## Quick publish steps
1. Create a GitHub repo (e.g. `raceroom-academy`)
2. Upload **everything** in this folder (index.html + assets/)
3. Repo Settings → Pages → Deploy from branch → `main` / root
4. Your site will be live at: `https://YOURUSERNAME.github.io/raceroom-academy/`

## Update links
- Discord link is already set: https://discord.gg/ZG4yKhffph
- Add YouTube channel link in index.html under the Contact section.
